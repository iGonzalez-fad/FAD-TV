<?php namespace Andreyco\Instagram\Exception;

use Exception;

class PaginationException extends Exception {}
